#!/usr/bin/env python3
"""
Simulate SNP genotypes (0, 1, 2) for three populations.

Usage:
    python3 simulate_snps.py

Output:
    snp_genotypes.csv   90 individuals x 500 SNPs
                        columns: individual, population, SNP1 ... SNP500

How the data are simulated:
    1. Draw an ancestral allele frequency for each SNP (between 0.1 and 0.9).
    2. For each population, shift the ancestral frequencies a little
       (normal noise, sd = 0.1) to mimic genetic drift after the split.
    3. For each individual, draw two alleles per SNP from the population
       frequency: genotype = number of alternative alleles (0, 1 or 2).
"""

import numpy as np
import pandas as pd

rng = np.random.default_rng(42)  # fixed seed: same data every run

n_snps = 500
n_per_pop = 30
populations = ["Pop_A", "Pop_B", "Pop_C"]
drift_sd = 0.1

# 1. Ancestral allele frequencies
ancestral_freq = rng.uniform(0.1, 0.9, n_snps)

genotypes, labels = [], []
for pop in populations:
    # 2. Population allele frequencies after drift
    pop_freq = np.clip(ancestral_freq + rng.normal(0, drift_sd, n_snps), 0.01, 0.99)
    # 3. Diploid genotypes
    genotypes.append(rng.binomial(2, pop_freq, size=(n_per_pop, n_snps)))
    labels += [pop] * n_per_pop

X = np.vstack(genotypes)
df = pd.DataFrame(X, columns=[f"SNP{i+1}" for i in range(n_snps)])
df.insert(0, "population", labels)
df.insert(0, "individual", [f"{p}_{i+1:02d}" for p in populations for i in range(n_per_pop)])
df.to_csv("snp_genotypes.csv", index=False)

print(f"Wrote snp_genotypes.csv: {X.shape[0]} individuals x {X.shape[1]} SNPs")
