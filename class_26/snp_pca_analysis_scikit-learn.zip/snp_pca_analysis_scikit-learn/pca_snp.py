#!/usr/bin/env python3
"""
PCA on SNP genotypes (0, 1, 2) with scikit-learn.

Usage:
    python3 pca_snp.py snp_genotypes.csv

Input: CSV with columns 'individual', 'population', then one column per SNP.
Output (written to the current directory):
    pca_scores.csv      PC1-PC10 for each individual
    pca_variance.csv    variance explained by each PC
    pca_top_snps.csv    SNPs with the largest loadings on PC1 and PC2
    pca_snp_plot.png    PC1 vs PC2 plot and scree plot
"""

import sys

import matplotlib
matplotlib.use("Agg")  # no display on Erdos: save plots to file
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

if len(sys.argv) != 2:
    sys.exit("Usage: python3 pca_snp.py snp_genotypes.csv")

# ---- 1. Read data -----------------------------------------------------------
df = pd.read_csv(sys.argv[1])
labels = df["population"].values
snp_cols = [c for c in df.columns if c not in ("individual", "population")]
X = df[snp_cols].values
print(f"Read {X.shape[0]} individuals x {X.shape[1]} SNPs")

# ---- 2. Standardize and run PCA ----------------------------------------------
X_scaled = StandardScaler().fit_transform(X)
n_pcs = 10
pca = PCA(n_components=n_pcs)
pcs = pca.fit_transform(X_scaled)
var = pca.explained_variance_ratio_ * 100

pc_names = [f"PC{i+1}" for i in range(n_pcs)]
scores = pd.DataFrame(pcs, columns=pc_names)
scores.insert(0, "population", labels)
scores.insert(0, "individual", df["individual"].values)
scores.to_csv("pca_scores.csv", index=False)

pd.DataFrame({"PC": pc_names, "variance_explained_pct": var.round(3)}).to_csv(
    "pca_variance.csv", index=False)

print("\nVariance explained (%):")
for name, v in zip(pc_names[:5], var[:5]):
    print(f"  {name}: {v:.2f}")

# ---- 3. SNPs with the largest loadings on PC1 and PC2 ------------------------
loadings = pd.DataFrame(pca.components_[:2].T, index=snp_cols, columns=["PC1", "PC2"])
top = []
for pc in ["PC1", "PC2"]:
    best = loadings[pc].abs().sort_values(ascending=False).head(10).index
    for snp in best:
        row = {"PC": pc, "SNP": snp, "loading": round(loadings.loc[snp, pc], 4)}
        row.update(df.groupby("population")[snp].mean().round(2).to_dict())
        top.append(row)
pd.DataFrame(top).to_csv("pca_top_snps.csv", index=False)

# ---- 4. Plot -----------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
for pop in sorted(set(labels)):
    idx = labels == pop
    axes[0].scatter(pcs[idx, 0], pcs[idx, 1], label=pop, alpha=0.8, edgecolor="k")
axes[0].set_xlabel(f"PC1 ({var[0]:.1f}%)")
axes[0].set_ylabel(f"PC2 ({var[1]:.1f}%)")
axes[0].set_title("PCA of SNP genotypes")
axes[0].legend()

axes[1].bar(range(1, n_pcs + 1), var, color="gray")
axes[1].set_xlabel("Principal component")
axes[1].set_ylabel("Variance explained (%)")
axes[1].set_title("Scree plot")

plt.tight_layout()
plt.savefig("pca_snp_plot.png", dpi=150)

print("\nWrote: pca_scores.csv, pca_variance.csv, pca_top_snps.csv, pca_snp_plot.png")
