#!/bin/bash

######################################################
##### SNPs PCA Analysis with scikit-learn ############
##### Jose Barba #####################################
######################################################

### NOTE: run these commands one section at a time, not as a single script

### connect to the remote server erdos using ssh (replace erdos_username with your own username)
ssh erdos_username@erdos.dsm.fordham.edu

### copy the snp_pca_analysis_scikit-learn dataset to the home directory
cp -r /u/erdos/jbarba/public/snp_pca_analysis_scikit-learn ~/

### change to the snp_pca_analysis_scikit-learn directory
cd ~/snp_pca_analysis_scikit-learn

### activate the python environment
conda activate bioinformatics

### install numpy, pandas, scikit-learn, and matplotlib
conda install -c conda-forge numpy pandas scikit-learn matplotlib

### run the pca analysis
python3 pca_snp.py snp_genotypes.csv

### deactivate the conda environment
conda deactivate

### exit the erdos server
exit

##### run the following from your own computer #####

### in mac and linux (terminal): transfer the snp_pca_analysis_scikit-learn directory to your home directory
### NOTE: SUBSTITUTE erdos_username WITH YOUR OWN ERDOS USERNAME
scp -r erdos_username@erdos.dsm.fordham.edu:~/snp_pca_analysis_scikit-learn ~/

### in windows (powershell): transfer the snp_pca_analysis_scikit-learn directory to your home directory
### NOTE: SUBSTITUTE erdos_username WITH YOUR OWN ERDOS USERNAME
scp -r erdos_username@erdos.dsm.fordham.edu:~/snp_pca_analysis_scikit-learn "$HOME"
